import random

wordFile = open("words.txt",'r')
wordlist = wordFile.readlines()

def altscore(word):
   score = 0.0
   leftHand = "asdfgzxcvbqwert"
   rightHand = "lkjhpoiuymn"
   for i in range(len(word)-1):
       if word[i] in leftHand and word[i+1] in rightHand:
           score += 1
       elif word[i] in rightHand and word[i+1] in leftHand:
           score += 1

   return score / (len(word)-1)

goodwords = [word[:-1] for word in wordlist if altscore(word) >= 0.7]

def makePassword(goodwords):
    done = False
    while not done:
        passlist = []
        for i in range(4):
            passlist.append(goodwords[random.randrange(len(goodwords))])
        if len("".join(passlist)) <= 20 and len("".join(passlist)) > 10:
            done = True
    return "/".join(passlist)

print makePassword(goodwords)